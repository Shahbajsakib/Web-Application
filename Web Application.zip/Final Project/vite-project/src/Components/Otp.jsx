import React from 'react';
import { useState } from 'react';
import './Otp.css';

function Otp() {
    const [otp, setOtp] = useState("");
    const [verificationError, setVerificationError] = useState("");

    const verifyOtp = (event)=>{
        event.preventDefault();
        const urlParams = new URLSearchParams(window.location.search);
        const email = urlParams.get('email');
        const formValues = {email, otp};
        fetch('http://127.0.0.1:8000/verify', {
            method: 'post',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify(formValues)    
        })
        .then(res=>res.json())
        .then(data=>{
            if (data && data.detail === "User activation successful") {
                window.location = "http://localhost:5173/login"
            } else{
                setVerificationError(data.detail ? data.detail : data);
            }
        });
    }
    
    return (
        <div className="container">
            <form action="/a" className="otp-form">
                <h1 className="log">OTP Code</h1>
                <div className="text-field">
                    <label htmlFor="otp">Confirm OTP</label>
                    <input type="text" value={otp} onChange={e=>setOtp(e.target.value)} id="otp" className="otp-input" placeholder="Enter OTP Code" />
                    <br />
                    <br />
                    <button className='btn' onClick={e=>verifyOtp(e)}>Confirm</button>
                    <div style={{padding: "10px", color: "red", marginBottom: "30px"}}>{verificationError}</div>
                </div>
            </form>
        </div>
    );
}

export default Otp;
