



// import React from 'react';
import './Product.css';
import pd1 from "../Assets/pro-1.jpeg";
import pd2 from "../Assets/pro-2.jpeg";
import pd3 from "../Assets/pro-3.jpeg";
import pd4 from "../Assets/pro-1.jpeg";
import pd5 from "../Assets/product-12.jpg"
import pd6 from "../Assets/product-6.jpg"
import pd7 from "../Assets/product-10.jpg"
import pdw1 from "../Assets/category-3.jpg"
import pdw2 from "../Assets/new3.jpeg"
import pdw3 from "../Assets/new2.jpeg"
import pdw4 from "../Assets/new.jpeg"
import pdw5 from "../Assets/new5.jpeg"
import pdk1 from "../Assets/WhatsApp Image 2024-02-12 at 23.13.35.jpeg"
import pdk2 from "../Assets/WhatsApp Image 2024-02-12 at 23.13.34.jpeg"

function Product() {
    return (
        <div id='product' className="small-container">
            {/* MEN'S SECTION */}
            <h2 className="title">MEN's SECTION</h2>
            <div className="row">
                {/* Add products for men's section here */}
                <div className="col-4">
                <img src={pd1} alt="Green Jacket" />
                <h4>Red Jacket</h4>
                <p>3500&#x09F3;</p>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* mens product no 2 */}
                <div className="col-4">
                <img src={pd2} alt="Winter Jacket" />
                <h4>Winter Jacket</h4> 
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>4700&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* mens product no 3 */}
                <div className="col-4">
                <img src={pd3} alt="Red Jacket" />
                <h4>Red Jacket</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>3500&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* mens product 4 */}
                <div className="col-4">
                <img src={pd4} alt="Green Jacket & Black Pant" />
                <h4>Red Jacket</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>6500&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* mens product 5 */}
                <div className="col-4">
                <img src={pd5} alt="Trouser" />
                <h4>Trouser</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>1090&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* mens product 6 */}
                <div className="col-4">
                <img src={pd6} alt="T-Shirt" />
                <h4>Black T0 Shirt</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>990&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* mens product 7 */}
                <div className="col-4">
                <img src={pd7} alt="Black Jumper" />
                <h4>Black Jumper</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>2200&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>


                {/* Example: */}
                {/* <div className="col-4">
                    <img src={require('../Assets/pro-1.jpeg').default} alt="Product 1" />
                    <h4>Men's Product 1</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>$19.99</p>
                    <button className="add-to-cart-btn">Add to Cart</button>
                </div> */}
                {/* End of products for men's section */}
            </div>

            {/* WOMEN'S SECTION */}
            <h2 className="title">WOMEN's SECTION</h2>
            <div className="row">

                {/* womens product 1  */}
                <div className="col-4">
                <img src={pdw1} alt="Addidas Hoodies" />
                <h4>Addidas Hoodies</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>3500&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>
                {/* Womens products 2 */}
                <div className="col-4">
                <img src={pdw2} alt="2 pieces" />
                <h4>Two Pieces</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>1580&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* womwns products 3 */}
                <div className="col-4">
                <img src={pdw3} alt="Pink Lehenga" />
                <h4>Pink Lehenga</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>11999&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* womens products 4 */}
                <div className="col-4">
                <img src={pdw4} alt="Red Lehenga" />
                <h4>Red Lehenga</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>18900&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* womens product 5 */}
                <div className="col-4">
                <img src={pdw5} alt="Bosonto Shaari" />
                <h4>Boshonto Shaari</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>1500&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>


                {/* Add products for women's section here */}
                {/* Example: */}
                {/* <div className="col-4">
                    <img src={require('../Assets/women-product-1.jpg').default} alt="Product 1" />
                    <h4>Women's Product 1</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>$29.99</p>
                    <button className="add-to-cart-btn">Add to Cart</button>
                </div> */}
                {/* End of products for women's section */}
            </div>

            {/* KIDS' SECTION */}
            <h2 className="title">KID's SECTION</h2>
            <div className="row">
                {/* Add products for kids' section here */}

                {/* kids products 1 */}
                <div className="col-4">
                <img src={pdk1} alt="Panjabi" />
                <h4>Panjabi</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>1300&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* kids products 2 */}
                <div className="col-4">
                <img src={pdk2} alt="Mixed Colour Panjabi" />
                <h4>Mixed Colour Panjabi</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>1700&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>

                {/* kids products 3 */}
                <div className="col-4">
                <img src={pdk1} alt="Kid's Panjabi" />
                <h4>Kid's Panjabi</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>1100&#x09F3;</p>
                <button className="add-to-cart-btn">Add to Cart</button>
                </div>
                {/* Example: */}
                {/* <div className="col-4">
                    <img src={require('../Assets/kids-product-1.jpg').default} alt="Product 1" />
                    <h4>Kid's Product 1</h4>
                    <div className="rating">
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star checked"></span>
                        <span className="fa fa-star"></span>
                        <span className="fa fa-star-o"></span>
                    </div>
                    <p>$9.99</p>
                    <button className="add-to-cart-btn">Add to Cart</button>
                </div> */}
                {/* End of products for kids' section */}
            </div>
        </div>
    );
}

export default Product;
