


// import Login from './Components/Login'
import Product from './Components/Product'
// import Signup from './Components/Signup'
// import About from './Components/About'
// import Otp from './Components/Otp'
import Front from './Components/Front'


function App() {
 

  return (
    <>
     
     
    
     <Front />
      <Product />
     {/* <Signup/>
     <Login/>
     <Otp/>
     <Product/>
     <About/> */}
     
    </>
  )
}

export default App
